from lib.Bodies import Bodies
from lib.Tools import JsonUtils, Menu
from lib.RenderEngine import RenderEngine

SYSTEM_CFG_PATH = "./config/system.json"

Menu.display_menu()
print('Welcome to Asteroid physics engine !')

if __name__ == '__main__' :


    # STEP 1: Read the configuration file for bodies
    bodies_config = JsonUtils.load_json(SYSTEM_CFG_PATH)
    PhysicalBodies = {}


    # STEP 2: Initialise the bodies
    for name,cfg in bodies_config.items() :
        print(f"    >>INFO : ADD New Body to the map : {name}")

        new_body = Bodies.Body(name, cfg['type'], cfg['mass_kg'], cfg['radius_m'])

        new_body.position       = cfg['position']
        new_body.velocity       = cfg['velocity']
        new_body.acceleration   = cfg['acceleration']


        try :                                               # Set the body's color if it has been predefined
            new_body.color      = cfg['color']
        except :                                            # Otherwise the body will be white
            new_body.color      = [255, 255, 255]


        if new_body.get_Type().upper() != 'ORIGIN' :        # A trouver plus opti/efficace mais pas urgent => le + lourd
            PhysicalBodies[name] = new_body

        else :
            origin = new_body


    # STEP 3: Print an intial creation status of bodies...

    origin.get_status()
    for body_name in PhysicalBodies.keys() :
        PhysicalBodies[body_name].get_status()


    # STEP 4: Initialize interactions between bodies

    origin.InitializeOrbitalData(origin)

    for body in PhysicalBodies.values() :                   # All bodies will be attracted by the origin
        body.InitializeOrbitalData(origin)

    for body in PhysicalBodies.values() :
        body.UpdateAppliedForces(PhysicalBodies)            # Set others bodies which attract the body


    # STEP 5: Initialise the engine and run it!
    """with open('coord.csv', 'w', encoding='utf-8') as coord:
        coord.write("x;y;z;x';y';z'\n")  # Ajouter l'entête
        
        while True :
            coord.write(f"{PhysicalBodies['DG IV'].position[0]};{PhysicalBodies['DG IV'].position[1]};{PhysicalBodiesPhysicalBodies['DG IV'].position[2]};{PhysicalBodies['Moon'].position[0]};{PhysicalBodies['Moon'].position[1]};{PhysicalBodies['Moon'].position[2]}\n")
            for body in PhysicalBodies.values() :
                body.UpdateAppliedForces(PhysicalBodies)
                body.NextPosition()
    """

    #print(PhysicalBodies['Callisto'].all_forces_list)

    Render = RenderEngine.Render()
    Render.Initialize(PhysicalBodies, origin)
    Render.Run()