🚀 Merci d'avoir téléchargé Asteroid !
🛠️ Cette version est provisoire sur GitHub.

Lancer Asteroid :
Exécutez Asteroid.py avec python depuis le dossier Asteroid (sinon, les librairies ne pourront pas être chargées).

Exécution :
Ouvrez un terminal (ex. : PowerShell).
Tapez et entrez            : cd /chemin-vers-le-dossier/Asteroid-Space_Physics_Engine
Puis lancez le script avec : python Asteroid.py

Commandes clavier
	Zoom + : Molette souris haut
	Zoom - : Molette souris bas
	Ralentir le temps (x0.1) : Touche R
	Accélérer le temps (x10) : Touche T
	Centrer la vue sur un astre : clique droit (dessus)


⚙️ Asteroid continuera d’évoluer avec des calculs plus simples et optimisés ainsi que l’ajout de nouvelles fonctionnalités.

🎯 l'objectif final est d'en faire un simulateur en 3D