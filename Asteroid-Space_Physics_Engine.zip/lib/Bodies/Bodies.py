from lib.Tools.Utils import distance, projection_xyz, norm
from time import time


NEWTON_G = 6.67e-11                         # Gravitational constant


class Body:
    '''
    Creation of the Body class which brings together all physical bodies
    '''
    def __init__(self, name, type, mass_kg, radius_m):

        self.name           = name
        self.type           = type
        self.mass_kg        = mass_kg
        self.radius_m       = radius_m

        self.color = []                     # Color used by the Render Engine to draw the body


        self.StartTime  = 0
        self.EndTime    = 0
        self.dt_s       = 0
        self.TimeScale  = 1


        self.all_forces_list = {
            'User_applied_force':[0,0,0],   # Force applied by the user to the body (moteurs...)
            'External_bodies':{}            # Force applied by other bodies
        }
        self.force_sum      = [0,0,0]


        self.position       = [0, 0, 0]     # List [x, y, z]
        self.velocity       = [0, 0, 0]     # List [vx, vy, vz]
        self.acceleration   = [0, 0, 0]     # List [ax, ay, az]


    ###############################  SETTERS  ###############################


    def Set_dt_s(self):
        return self.EndTime - self.StartTime


    ###############################  GETTERS  ###############################


    def get_Name(self) :
        return self.name

    def get_Type(self) :
        return self.type

    def get_Mass(self) :
        return self.mass_kg

    def get_Radius(self) :
        return self.radius_m

    def get_Color(self) :
        return self.color

    def get_Position(self) :
        return self.position

    def get_dt_s(self) :
        return self.dt_s

    def get_TimeScale(self) :
        return self.TimeScale

    def get_AllForcesList(self) :
        return self.all_forces_list

    def get_ForceSum(self) :
        return self.force_sum

    def get_Velocity(self) :
        return self.velocity

    def get_Acceleration(self) :
        return self.acceleration

    def get_DominantBody(self) :
        return self.dominant_body

    def get_SOI_Radius(self) :
        return self.SOI_radius_m

    def get_status(self) :
        print( '    >>INFO : Object Status')
        print(f'         -Name              : {self.get_Name()}')
        print(f'         -Type              : {self.get_Type()}')
        print(f'         -Mass (kg)         : {self.get_Mass()}')
        print(f'         -Radius (m)        : {self.get_Radius()}')
        print(f'         -position          : {self.get_Position()}')
        print(f'         -velocity          : {self.get_Velocity()}')
        print(f'         -acceleration      : {self.get_Acceleration()}')
        print(f'         -current force     : {self.get_ForceSum()}\n')


##############################  ORBIT  ##############################


    def InitializeOrbitalData(self, origin) :
        '''
        Initialize the orbit data
        '''
        print(f'    >>INFO : Initializing {self.get_Name()}\'s orbital info')
        if self == origin :
            self.SOI_radius_m = float('inf')                                        # Infinitely large value to avoid physical objects to exit the system
            self.SetDominantBody()
            print(f'    >>INFO : {self.get_Name()} is now the system\'s origin')

        else :                                                                      # The orbital properties of the body around the origin => These will be updated after
            self.AddGravitationalForce(origin)
            self.semiMajorAxis = self.ComputeSemiMajorAxis()

            if self.type.upper() == 'CELESTIAL_BODY':
                self.SOI_radius_m = self.Set_SOI_Radius(self.dominant_body)

            else :
                self.SOI_radius_m = 0


    def ComputeSemiMajorAxis(self) :
        '''
        Compute the semi major axis of the orbit   => will soon be Update_orbital_data => Update object's orbital data (list of orbit's data)
        '''
        self.SetDominantBody()
        dominant_body = self.get_DominantBody()

        if self != dominant_body:
            mu = dominant_body.get_Mass()*NEWTON_G/(10**9)                          # Standard gravitational Parameter converted in km^(3)*s^(-2)
            velocity_norm = norm(self.velocity)/1000                                # Velocity vector norm converted in km*s^(-1)
            r = distance(self.get_Position(), dominant_body.get_Position())/1000    # Distance between both bodies converted in km

            a = 1/( (2/r) - ((velocity_norm**2)/mu) )                               # Semi major axis in km    |## LATEX ##| a = \frac{1}{\frac{2}{r}-\frac{v^{2}}{\mu}}

        else :
            a = None
            print(f'    >>ERROR : Unable to compute {dominant_body.get_Name()}\'s orbit data around himself')

        return a

    def SetDominantBody(self):
        '''
        Determine the dominant body
        '''
        if self.get_Type().upper() == 'ORIGIN' :
            dominant_body = self

        else :
            dominant_body = None
            dominant_body_attraction_norm = 0

            for applier in self.all_forces_list['External_bodies'].values() :       # Search the dominant body of the body
                if applier['type'].upper() == 'GRAVITATIONAL':
                    if norm(applier['projection']) >= dominant_body_attraction_norm:
                        dominant_body = applier['applier']
                        dominant_body_attraction_norm = norm(applier['projection'])

        self.dominant_body = dominant_body

    def Set_SOI_Radius(self, dominant_body):                                        # Sphere Of Influence in meters
        '''
        Compute the radius of the sphere of influence in meters
        '''
        M = dominant_body.get_Mass()
        m = self.get_Mass()

        R_SOI = self.semiMajorAxis * ( (m/M) ** (2/5) ) * 1000                      # Sphere Of Influence radius    |## LATEX ##| {\displaystyle r_{SOI}=a\left({\frac {m}{M}}\right)^{2/5}}

        return R_SOI


    ######################### Forces and Movement  ##########################


    def AddGravitationalForce(self, Gravity_applier):
        '''
        Add a new gravitational force
        '''
        applier_name = Gravity_applier.get_Name()

        if self != Gravity_applier :

            if applier_name not in self.all_forces_list['External_bodies']:
                Gravitational_force = self.ComputeGravitationalForceBy(Gravity_applier)
                self.all_forces_list['External_bodies'][applier_name] = {
                    'type'          : 'gravitational',
                    'applier'       : Gravity_applier,
                    'projection'    : Gravitational_force
                }
                print(f'    >>INFO : {applier_name} is now attracting {self.get_Name()} ')

            else :
                print(f'    >>ERROR : {applier_name} was already attracting {self.get_Name()} before. It can not be added twice')

        else :
            print(f'    >>ERROR : {applier_name} can\'t attract himself')


    def RemGravitationalForce(self, Gravity_applier) :
        '''
        Remove an already existing gravitational force
        '''
        applier_name = Gravity_applier.get_Name()

        if applier_name in self.all_forces_list['External_bodies'] :

            for applier, force in self.all_forces_list['External_bodies'].items() :
                if force['type'].upper() == 'GRAVITATIONAL' :
                    gravit_force = applier

            try :
                del self.all_forces_list['External_bodies'][gravit_force]
                print(f'    >>INFO : {applier_name} no longer attracts {self.get_Name()}')
            except :
                print(f'    >>ERROR : No gravitational force from {applier_name} found')

        else :
            print(f'    >>ERROR : {applier_name} wasn\'t interracting with {self.get_Name()} before')


    def ComputeGravitationalForceBy(self, gravity_applier) :
        '''
        Compute the gravitational force created by an external object at a precise moment
        '''
        gravity_applier_position = gravity_applier.get_Position()
        gravity_applier_mass = gravity_applier.get_Mass()

        dist_self_applier = distance(self.get_Position(), gravity_applier_position)
        Gravitational_norm = NEWTON_G * gravity_applier_mass * self.mass_kg / dist_self_applier**2  # Gravitational Force norm    |## LATEX ##| F = G \frac{m_1 m_2}{d^2}
        Gravitational_force = projection_xyz(Gravitational_norm, self.get_Position(), gravity_applier_position)

        return Gravitational_force


    def UpdateAppliedForces(self, PhysicalBodies) :
        '''
        Update forces that apply to the physical object
        '''
        for body in PhysicalBodies.values() :
            if self != body :
                if distance(self.get_Position(), body.get_Position()) <= body.get_SOI_Radius():
                    if body.get_Name() not in self.all_forces_list['External_bodies'] :
                        self.AddGravitationalForce(body)
                else :
                    if body.get_Name() in self.all_forces_list['External_bodies'] :
                        self.RemGravitationalForce(body)
        self.ComputeSemiMajorAxis()
        self.SOI_radius_m = self.Set_SOI_Radius(self.dominant_body)


    def UpdateExternalForces(self):
        '''
        Recompute all externals forces
        '''
        for force_name in self.all_forces_list['External_bodies'].keys() :

            if self.all_forces_list['External_bodies'][force_name]['type'].upper() == 'GRAVITATIONAL' :

                updated_force = self.ComputeGravitationalForceBy(self.all_forces_list['External_bodies'][force_name]['applier'])
                self.all_forces_list['External_bodies'][force_name]['projection'] = updated_force


    def UpdateForceSum(self):
        '''
        Updating the components of sum of forces
        '''
        self.UpdateExternalForces()

        self.force_sum=[0,0,0]

        for body_name in self.all_forces_list['External_bodies'].keys():

            self.force_sum[0] = self.force_sum[0] + self.all_forces_list['External_bodies'][body_name]['projection'][0]
            self.force_sum[1] = self.force_sum[1] + self.all_forces_list['External_bodies'][body_name]['projection'][1]
            self.force_sum[2] = self.force_sum[2] + self.all_forces_list['External_bodies'][body_name]['projection'][2]

        self.force_sum[0] = self.force_sum[0] + self.all_forces_list['User_applied_force'][0]
        self.force_sum[1] = self.force_sum[1] + self.all_forces_list['User_applied_force'][1]
        self.force_sum[2] = self.force_sum[2] + self.all_forces_list['User_applied_force'][2]


    def NextPosition(self):
        '''
        Compute the next position of the current object after a time_step increment
        '''
        self.UpdateForceSum()

        self.EndTime = time()
        self.dt_s = self.Set_dt_s() * self.get_TimeScale()

        # 2nd Newton's Law :    |## LATEX ##| \sum_{}^{}\overrightarrow{F}=m\overrightarrow{a}
        self.acceleration  = [
            self.force_sum[0] / self.get_Mass(),
            self.force_sum[1] / self.get_Mass(),
            self.force_sum[2] / self.get_Mass(),
        ]

        #print(f'    >>Updated acceleration for {self.get_Name()}={self.acceleration}')

        # Integration of the acceleration (ax, ay, az) to compute the velocity (vx, vy, vz)
        self.velocity = [
            self.acceleration[0]*self.get_dt_s() + self.velocity[0],
            self.acceleration[1]*self.get_dt_s() + self.velocity[1],
            self.acceleration[2]*self.get_dt_s() + self.velocity[2],
        ]

        # Integration of the velocity (vx, vy, vz) to compute the position (x, y, z)
        self.position = [
            self.velocity[0]*self.get_dt_s() + self.position[0],
            self.velocity[1]*self.get_dt_s() + self.position[1],
            self.velocity[2]*self.get_dt_s() + self.position[2],
        ]

        self.StartTime = time()