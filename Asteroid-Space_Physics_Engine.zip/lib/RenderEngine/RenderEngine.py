import pygame
import sys
from time import time
from lib.Tools.Utils import distance, norm

WIDTH, HEIGHT = 1350, 600

class Render():
    def __init__(self) :

        pygame.init()

        self.width = WIDTH
        self.height =  HEIGHT
        self.screen = pygame.display.set_mode((self.width, self.height), pygame.RESIZABLE)

        self.PhysicalBodies = {}
        self.origin = None
        self.ScreenCenter = None

        self.scale = 1
        self.running = True


    ###############################  GETTERS  ###############################


    def get_PhysicalBodies(self) :
        return self.PhysicalBodies
    
    def get_Scale(self) :
        return self.scale

    def get_RelativePosition(self, body) :
        if body == self.ScreenCenter :
            screenPosition = [self.width/2, self.height/2]

        else :
            screenPosition = [int( ( (body.get_Position()[0] - self.ScreenCenter.get_Position()[0] ) * self.scale) + self.width/2  ),
                              int(-( (body.get_Position()[1] - self.ScreenCenter.get_Position()[1] ) * self.scale) + self.height/2 )]   # Negative because Pygame increases y axis downward

        return screenPosition 


    ###############################  BODIES  ################################


    def LoadBodies(self, PhysicalBodies, origin) :
        self.PhysicalBodies = PhysicalBodies
        self.origin = origin
    
    def UpdateDrawList(self) :
        '''
        Update which body will be drawn on the screen
        '''
        OriginRelativePosition = self.get_RelativePosition(self.origin)
        RelativeDistance = distance(OriginRelativePosition, self.get_RelativePosition(self.ScreenCenter)) - self.origin.get_Radius()*self.scale

        if RelativeDistance <= norm(self.get_RelativePosition(self.ScreenCenter)):
            self.DrawBody(self.origin)

        for body in self.PhysicalBodies.values() :
            BodyRelativePosition = self.get_RelativePosition(body)
            RelativeDistance = distance(BodyRelativePosition, self.get_RelativePosition(self.ScreenCenter)) - body.get_Radius()*self.scale

            if RelativeDistance <= norm(self.get_RelativePosition(self.ScreenCenter)):
                self.DrawBody(body)


    def DrawBody(self, body) :
        body_RelativePosition = self.get_RelativePosition(body)

        if int(body.get_Radius()) != 0 :
            radius = body.get_Radius() * self.get_Scale()
            if radius < 1 :
                radius = 1

        pygame.draw.circle(self.screen, body.get_Color(), body_RelativePosition, radius)

        '''if body.get_Type() == 'Celestial_body' and body.get_DominantBody().get_Name() == 'Sun':      # Draw Sphere of Influence
            pygame.draw.circle(self.screen, (0,0,0), body_RelativePosition, body.get_SOI_Radius()*self.get_Scale())'''


    def UpdateAllPhysicalBodies(self) :
        for body in self.PhysicalBodies.values() :
            body.UpdateAppliedForces(self.get_PhysicalBodies())
            body.NextPosition()


    #########################  INTERFACE MANAGMENT  #########################


    def SetDefaultScale(self) :
        CenterObjectSize = 10                       # Central body size
        self.scale = CenterObjectSize/float(self.ScreenCenter.get_Radius())

    def Initialize(self, PhysicalBodies, origin) :

        # STEP 1 : Load Bodies and set the center of the screen
        self.LoadBodies(PhysicalBodies, origin)
        self.ScreenCenter = self.origin

        # STEP 2 : Set the initial scalet
        self.SetDefaultScale()


    def Run(self) :

        self.running = True

        self.SetDefaultScale()

        for body in self.PhysicalBodies.values() :
            body.StartTime = time()

        while self.running:

            for event in pygame.event.get() :

                if event.type == pygame.QUIT :
                    self.running = False

                elif event.type == pygame.VIDEORESIZE :
                    WIDTH, HEIGHT = event.w, event.h
                    self.width = WIDTH
                    self.height = HEIGHT
                    self.screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
                    print(f'    >>INFO : Screen has been resized in {WIDTH}x{HEIGHT}')
                
                elif event.type == pygame.MOUSEBUTTONDOWN :

                    if event.button == 1 :          # Mouse Left Click

                        if distance(event.pos, self.get_RelativePosition(self.origin)) <= self.origin.get_Radius()*self.get_Scale()+10 and self.origin != self.ScreenCenter: 
                            self.ScreenCenter = self.origin
                            print(f'    >>INFO : {self.ScreenCenter.get_Name()} is now the screen\'s center')

                        else :
                            for body in self.get_PhysicalBodies().values() :
                                if distance(event.pos, self.get_RelativePosition(body)) <= body.get_Radius()*self.get_Scale()+10 and body != self.ScreenCenter:
                                    self.ScreenCenter = body
                                    print(f'    >>INFO : {self.ScreenCenter.get_Name()} is now the screen\'s center')

                    elif event.button == 4 :        # Mouse : Wheel Up
                        self.scale *= 1.1

                    elif event.button == 5 :        # Mouse : Wheel Down
                        self.scale /= 1.1
                
                elif event.type == pygame.KEYDOWN:

                    if event.key == pygame.K_r:     # Keyboard : Key R
                        for body in self.get_PhysicalBodies().values() :
                            body.TimeScale /= 10

                    elif event.key == pygame.K_t:   # Keyboard : Key T
                        for body in self.get_PhysicalBodies().values() :
                            body.TimeScale *= 10


            self.screen.fill((30,30,30))

            self.UpdateAllPhysicalBodies()
            self.UpdateDrawList()

            pygame.display.flip()


        pygame.quit()
        sys.exit()