import json

def load_json(file_path): 
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            data = json.load(file)

        return(data)

    except Exception as error:
        print(f"    >>ERROR : An error occurred while opening the JSON file : {error}")