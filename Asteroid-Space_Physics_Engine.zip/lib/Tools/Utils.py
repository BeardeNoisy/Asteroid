from math import sqrt

def distance(object_a, object_b):
    '''
    Calculer la distance entre deux objets
    '''
    return sqrt(sum( (object_a[i] - object_b[i])**2 for i in range(len(object_a))))


def projection_xyz(force_norm, source, target):       
    '''
    Projeter un vecteur de norme F et de direction entre source et destination sur les axes (x, y, z) 
    Sens : Source => Target
    '''
    vector_ST = (               # Création d'un vecteur directeur du vecteur à projeter
        target[0] - source[0],
        target[1] - source[1],
        target[2] - source[2])

    vector_norm = distance(source, target)

    unit_vector = (             # Création d'un vecteur unitaire (norme = 1) projeté sur les axes (x, y, z)
        vector_ST[0] / vector_norm,
        vector_ST[1] / vector_norm,
        vector_ST[2] / vector_norm,
        )

    projection = (              # On multiplie les trois axes du vecteur unitaire par la norme du vecteur à projeter
        unit_vector[0] * force_norm,
        unit_vector[1] * force_norm,
        unit_vector[2] * force_norm,
    )

    return projection


def norm(projected_vector) :
    return sqrt(sum(i**2 for i in projected_vector))